Simple Weather App
------------------

This is a simple weather app that uses open weather API from http://openweathermap.org/api

How To Use The App
-----------------------
*Windows Users:
All you have to do is to  unzip the zipped file in one folder and run the WeatherApp.exe file. 


*macOS Users
- you can download MONO from: http://www.mono-project.com/
- open the terminal and go to the directory which you have unzipped the file in
- type in $ mono WeatherApp.exe

After you successfully  opened the application it will ask you to input the name of city and ID of the country (country's ID is a two Letter unique word, e.g. United States: US NetherLand: NL, Germany: DE, France:Fr, Iran: Ir, Afghanistan:Af and etc.)
 